﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentCrud.Models;
using System.Data;
using System.Data.SqlClient;


namespace StudentCrud.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public void InsertRecord(studentClass ss)
        {



            if (!string.IsNullOrEmpty(ss.name) && !string.IsNullOrEmpty(ss.roll) && !string.IsNullOrEmpty(ss.age) && !string.IsNullOrEmpty(ss.dob) && !string.IsNullOrEmpty(ss.Class) && !string.IsNullOrEmpty(ss.sdate))
            {

                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PAU4AHF\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("InsertData", con);
                cmd.CommandType = CommandType.StoredProcedure;




                cmd.Parameters.AddWithValue("@name", ss.name);
                cmd.Parameters.AddWithValue("@roll", Convert.ToInt32(ss.roll));
                cmd.Parameters.AddWithValue("@age", Convert.ToInt32(ss.age));
                cmd.Parameters.AddWithValue("@dob", ss.dob);
                cmd.Parameters.AddWithValue("@Class", ss.Class);
                cmd.Parameters.AddWithValue("@sdate", ss.sdate);
                if (ConnectionState.Closed == con.State)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                con.Close();
            }
           
    

        }

        public List<studentClass>GetAllData()
        {
            List<studentClass> lst = new List<studentClass>();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PAU4AHF\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("showData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if(ConnectionState.Closed==con.State)
            {
                con.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                lst.Add(new studentClass{
                    name=dr["name"].ToString(),roll=dr["roll"].ToString(),age=dr["age"].ToString(),dob=dr["dob"].ToString(),Class=dr["Class"].ToString(),sdate=dr["sdate"].ToString()
                });
            }
            con.Close();
            return lst;
        }

        public List<studentClass> GetSingleData(string id)
        {
            List<studentClass> lst = new List<studentClass>();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PAU4AHF\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("singleData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@roll", Convert.ToInt32(id));
            if (ConnectionState.Closed == con.State)
            {
                con.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lst.Add(new studentClass
                {
                    name = dr["name"].ToString(),
                    roll = dr["roll"].ToString(),
                    age = dr["age"].ToString(),
                    dob = dr["dob"].ToString(),
                    Class = dr["Class"].ToString(),
                    sdate = dr["sdate"].ToString()
                });
            }
            con.Close();
            return lst;
        }


        public ActionResult display()
        {
            return View();
        }
        public JsonResult getList()
        {
            return Json(GetAllData(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult getSingleRow(string roll)
        {
            return Json(GetSingleData(roll), JsonRequestBehavior.AllowGet);
        }

        public JsonResult deleteRecord(string  studentId)
        {

            

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PAU4AHF\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("deleteData", con);
                cmd.CommandType = CommandType.StoredProcedure;




                cmd.Parameters.AddWithValue("@roll", Convert.ToInt32(studentId));

                if (ConnectionState.Closed == con.State)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                con.Close();
                return Json("Data is deleted", JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                return Json("Record is not deleted", JsonRequestBehavior.AllowGet);
            }


        }

        public JsonResult updateRecord(string na, string ro, string ag,string bdate,string cls,string sda)
        {


            if (!string.IsNullOrEmpty(na) && !string.IsNullOrEmpty(ro) && !string.IsNullOrEmpty(ag) && !string.IsNullOrEmpty(bdate) && !string.IsNullOrEmpty(cls) && !string.IsNullOrEmpty(sda))
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PAU4AHF\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
                    SqlCommand cmd = new SqlCommand("updateData", con);
                    cmd.CommandType = CommandType.StoredProcedure;



                    cmd.Parameters.AddWithValue("@name", na);
                    cmd.Parameters.AddWithValue("@roll", Convert.ToInt32(ro));
                    cmd.Parameters.AddWithValue("@age", Convert.ToInt32(ag));
                    cmd.Parameters.AddWithValue("@dob", bdate);
                    cmd.Parameters.AddWithValue("@Class", cls);
                    cmd.Parameters.AddWithValue("@sdate", sda);

                    if (ConnectionState.Closed == con.State)
                    {
                        con.Open();
                    }
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return Json("Record Updated", JsonRequestBehavior.AllowGet);
                }
                catch (Exception e)
                {
                    return Json("Record is not updated", JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json("BOOM! All field should be filled.", JsonRequestBehavior.AllowGet);
            }

        }

    }
}
