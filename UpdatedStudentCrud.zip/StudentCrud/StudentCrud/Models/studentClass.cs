﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentCrud.Models
{
    public class studentClass
    {
        public string name { get; set; }
        public string roll{ get; set; }
        public string age { get; set; }
        public string dob { get; set; }

        public string Class { get; set; }
        public string sdate { get; set; }


    }
}